﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HESTEST
{
    public class ListHesMapModel
    {
        public Dictionary<string, HESResponseModel> success_map { get; set; }
        public Dictionary<string, string> unsuccess_map { get; set; }
    }
}
