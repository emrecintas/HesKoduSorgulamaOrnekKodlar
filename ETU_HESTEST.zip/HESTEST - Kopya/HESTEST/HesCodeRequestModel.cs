﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HESTEST
{
    public class HesCodeRequestModel
    {
        public string hes_code { get; set; }
    }
}
