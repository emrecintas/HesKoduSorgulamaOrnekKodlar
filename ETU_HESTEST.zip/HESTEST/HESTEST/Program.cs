﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HESTEST
{
    class Program
    {
        #region TEST
        //public static string urladress = "https://hesservis.turkiye.gov.tr/services/g2g/test/saglik/hes/";
        //public static string username = "ERZURUMTEKNIKUNIVERSITESIKULLANICIADIGELECEK";
        //public static string password = "PAROLA YAZILACAK";
        #endregion TEST


        #region GERÇEKORTAM
        public static string urladress = "https://hesservis.turkiye.gov.tr/services/g2g/saglik/hes/";
        public static string username = "ERZURUMTEKNIKUNIVERSITESIKULLANICIADIGELECEK";
        public static string password = "PAROLA YAZILACAK";
        #endregion GERÇEKORTAM



        static void Main(string[] args)
        {            
            var test2 = CheckHesCode("P2G88532S2");
            var test3 = CheckHesCode("M8N43729S5");

            var list = new List<String>();
            list.Add("P2G88532S2"); list.Add("M8N43729S5");
            var test4 = CheckHesCodes(list.ToArray());

            var aaaa = "";
        }



        public static HESResponseModel CheckHesCode(string hescode)
        {
            HESResponseModel res = new HESResponseModel();
            var hes = new HESApiService(urladress, username, password);

            var checkStr = hes.CheckHesCode("check-hes-code-plus", hescode);
            try
            {
                if (!string.IsNullOrEmpty(checkStr))
                {
                    res = JsonConvert.DeserializeObject<HESResponseModel>(checkStr);
                    if (res != null && res.expiration_date < DateTime.Now)
                    {
                        res.DonusMesaji = "Kodunuzun geçerlilik tarihi geçmiştir. Yeni bir kod almanız gerekmektedir";
                        return res;
                    }

                    res.SonucBasarili = true;
                    res.DonusMesaji = "Kodunuz geçerli !";
                }
                else
                {
                    res.DonusMesaji = "Geçersiz kod";
                    return res;
                }
            }
            catch (Exception e)
            {
                res.DonusMesaji = e.ToString();
            }

            return res;
        }


        public static ListHesMapModel CheckHesCodes(string[] hescodes)
        {
            ListHesMapModel res = new ListHesMapModel();
            //if (hescodes.Length > 500)
            //res.DonusMesaji = "Bir seferde en fazla 500 kod kontrol edilebilir";
            var hes = new HESApiService(urladress, username, password);
            var checkStr = hes.CheckHesCodes("check-hes-codes", hescodes);

            //var test = "{'success_map':{'F4G61346S2':{'expiration_date':'2021-01-15T10:05:00Z','current_health_status':'RISKLESS','masked_identity_number':'********000'},'P2G88532S2':{'expiration_date':'2020-11-30T22:35:00Z','current_health_status':'RISKLESS','masked_identity_number':'********000'}},'unsuccess_map':{'F4G61346S3':'hescodenotfound','C4G6-1346-S3':'hescodenotfound'}}";
            var searchStrRes = JsonConvert.DeserializeObject<ListHesMapModel>(checkStr);//test
            foreach (var success in searchStrRes.success_map)
            {
                if (success.Value.expiration_date < DateTime.Now)
                {
                    success.Value.DonusMesaji = "Kod geçerlilik tarihi geçmiştir.";
                }
                else
                    success.Value.SonucBasarili = true;
            }

            return searchStrRes;
        }




















    }
}
