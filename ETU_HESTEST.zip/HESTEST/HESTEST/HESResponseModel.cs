﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HESTEST
{
    public class HESResponseModel
    {
        public bool SonucBasarili { get; set; }
        public string DonusMesaji { get; set; }
        public DateTime expiration_date { get; set; }
        public string current_health_status { get; set; }
        public string masked_identity_number { get; set; }
        public string masked_firstname { get; set; }
        public string masked_lastname { get; set; }
        public string is_vaccinated { get; set; }
        public string is_immune { get; set; }
        public string last_negative_test_date { get; set; }



        
            
            
            
            

    }
}
